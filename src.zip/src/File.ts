export interface File {
  id?: number;
  bucket_id: number;
  filename: string;
  size: string;
  last_modified: any;
}